﻿using UnityEngine;

public class DisplayMessageManager : MonoBehaviour
{
    public Transform DisplayMessageRect;
}
